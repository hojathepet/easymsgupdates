param(
    [Parameter(Mandatory = $true)][int]$ParentPid,
    [Parameter(Mandatory = $true)][string]$InstallerPath,
    [Parameter(Mandatory = $true)][string]$AppPath,
    [Parameter(Mandatory = $true)][string]$LogPath,
    [Parameter(Mandatory = $true)][string]$Version,
    [Parameter(Mandatory = $true)][string]$ReadyPath,
    [switch]$NoErrorDialog
)

$ErrorActionPreference = 'Stop'
$handoffLog = [System.IO.Path]::ChangeExtension($LogPath, '.handoff.log')
Set-Content -LiteralPath $ReadyPath -Encoding ASCII -Value 'ready'

function Write-Step([string]$message) {
    Add-Content -LiteralPath $handoffLog -Encoding UTF8 -Value "$(Get-Date -Format o) $message"
}

try {
    Write-Step "Waiting for EasyMsg process $ParentPid to exit."
    $oldApp = Get-Process -Id $ParentPid -ErrorAction SilentlyContinue
    if ($null -ne $oldApp -and -not $oldApp.WaitForExit(60000)) {
        throw 'EasyMsg did not exit within 60 seconds.'
    }

    if (-not (Test-Path -LiteralPath $InstallerPath -PathType Leaf)) {
        throw "Installer missing: $InstallerPath"
    }

    # Start-Process joins argument arrays with spaces, so preserve quotes for
    # paths with spaces in one command-line string.
    $appDir = Split-Path -Parent $AppPath
    $setupArgs = '/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /CLOSEAPPLICATIONS ' +
        '/NORESTARTAPPLICATIONS /AUTOUPDATE=0 /DIR="' + $appDir + '" /LOG="' + $LogPath + '"'
    Write-Step "Starting installer: $InstallerPath"
    $setup = Start-Process -FilePath $InstallerPath -ArgumentList $setupArgs `
        -WindowStyle Hidden -Wait -PassThru
    Write-Step "Installer exit code: $($setup.ExitCode)"
    if ($setup.ExitCode -ne 0) {
        throw "Installer failed with exit code $($setup.ExitCode)."
    }

    $installedVersion = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($AppPath).ProductVersion
    if (($installedVersion -split '\+')[0] -ne $Version) {
        throw "Installed version $installedVersion does not match $Version."
    }

    Start-Process -FilePath $AppPath -WorkingDirectory $appDir | Out-Null
    Write-Step "Started EasyMsg $installedVersion."
} catch {
    Write-Step "Update failed: $($_.Exception.Message)"
    # Return to a usable app even if Setup failed. The handoff and installer
    # logs stay in the temp update directory for diagnosis.
    if (Test-Path -LiteralPath $AppPath -PathType Leaf) {
        try {
            Start-Process -FilePath $AppPath -WorkingDirectory (Split-Path -Parent $AppPath) | Out-Null
        } catch {
            Write-Step "Could not reopen EasyMsg: $($_.Exception.Message)"
        }
    }
    if (-not $NoErrorDialog) {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show(
            "EasyMsg update failed. Details: $handoffLog",
            'EasyMsg update',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
    exit 1
}
