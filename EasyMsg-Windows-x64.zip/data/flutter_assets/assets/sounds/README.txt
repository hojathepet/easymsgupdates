New Notification 040 by Universfield
Source: https://pixabay.com/sound-effects/technology-new-notification-040-493469/
License: Pixabay Content License, https://pixabay.com/service/license-summary/
Used as the bundled EasyMsg notification sound.
