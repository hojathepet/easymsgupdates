param([Parameter(Mandatory = $true)][string]$Config)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [Console]::OutputEncoding
try {
  $request = Get-Content -LiteralPath $Config -Raw -Encoding UTF8 | ConvertFrom-Json
  Add-Type -AssemblyName System.Drawing
  $printers = @(Get-Printer | Where-Object {
    $_.Name.Length -le 128 -and
    $_.PortName -notmatch '^(PORTPROMPT:|FILE:|SHRFAX:|FAX:)$' -and
    $_.DriverName -notmatch '(?i)(pdf|xps|fax|onenote)' -and
    $_.Name -notmatch '(?i)(Microsoft Print to PDF|XPS Document Writer|OneNote|^Fax$)'
  } | Select-Object -First 32)
  if ($request.action -eq 'list') {
    $default = [System.Drawing.Printing.PrinterSettings]::new().PrinterName
    $result = @($printers | ForEach-Object {
      @{name = $_.Name; default = ($_.Name -eq $default);
        available = ($_.PrinterStatus.ToString() -notmatch 'Offline|Error|NotAvailable')}
    })
    @{printers = $result} | ConvertTo-Json -Depth 4 -Compress
    exit 0
  }
  if ($request.action -eq 'capabilities') {
    if (@($printers | Where-Object Name -CEQ $request.printer).Count -ne 1) {
      throw 'Printer is not an installed physical printer'
    }
    $settings = [System.Drawing.Printing.PrinterSettings]::new()
    $settings.PrinterName = $request.printer
    if (-not $settings.IsValid) { throw 'Invalid printer' }
    $papers = @($settings.PaperSizes | Where-Object {
      $_.Width -gt 0 -and $_.Height -gt 0 -and $_.Width -le 99999 -and $_.Height -le 99999
    } | ForEach-Object {
      @{id = "p:$($_.RawKind):$($_.Width):$($_.Height)"; name = $_.PaperName}
    } | Sort-Object -Property { $_.id } -Unique | Select-Object -First 64)
    $sources = @($settings.PaperSources | ForEach-Object {
      @{id = "s:$($_.RawKind)"; name = $_.SourceName}
    } | Sort-Object -Property { $_.id } -Unique | Select-Object -First 32)
    $resolutions = @($settings.PrinterResolutions | ForEach-Object {
      @{id = "r:$([int]$_.Kind):$($_.X):$($_.Y)";
        name = $(if ($_.Kind.ToString() -eq 'Custom') { "$($_.X) x $($_.Y) DPI" } else { $_.Kind.ToString() })}
    } | Sort-Object -Property { $_.id } -Unique | Select-Object -First 32)
    @{capabilities = @{color = $settings.SupportsColor; duplex = $settings.CanDuplex;
      maxCopies = [Math]::Max(1, [Math]::Min(99, $settings.MaximumCopies));
      papers = $papers; sources = $sources; resolutions = $resolutions}} | ConvertTo-Json -Depth 6 -Compress
    exit 0
  }
  if ($request.action -notin @('print', 'validate')) { throw 'Unsupported operation' }
  $advanced = $request.settingsVersion -eq 2
  if ($request.copies -lt 1 -or $request.copies -gt $(if ($advanced) { 99 } else { 10 }) -or
      (-not $advanced -and $request.paper -notin @('a4', 'letter', 'photo')) -or
      $request.landscape -isnot [bool]) { throw 'Invalid print settings' }
  if (-not $advanced) {
    $request | Add-Member -NotePropertyMembers @{duplex = 'default'; color = 'default'; source = 'default';
      resolution = 'default'; collate = $true; pages = ''; scale = 'fit'; marginMm = 5; windowsDialog = $false} -Force
  }
  if ($request.duplex -notin @('default', 'simplex', 'vertical', 'horizontal') -or
      $request.color -notin @('default', 'color', 'mono') -or
      $request.scale -notin @('fit', 'actual', 'fill') -or
      $request.marginMm -lt 0 -or $request.marginMm -gt 25 -or
      $request.collate -isnot [bool] -or $request.windowsDialog -isnot [bool]) { throw 'Invalid advanced settings' }
  if ($request.action -eq 'print' -and
      @($printers | Where-Object Name -CEQ $request.printer).Count -ne 1) {
    throw 'Printer is not an installed physical printer'
  }
  $pdfPath = (Get-Item -LiteralPath $request.pdf).FullName
  if ((Get-Item -LiteralPath $pdfPath).Length -gt 25MB) { throw 'PDF exceeds limit' }
  $dllPath = Join-Path $request.dllDirectory 'pdfium.dll'
  if (-not (Test-Path -LiteralPath $dllPath -PathType Leaf)) { throw 'PDF renderer is missing' }
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -ReferencedAssemblies System.Drawing,System.Windows.Forms -TypeDefinition @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.IO;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Windows.Forms;

public static class EasyMsgPrint {
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
  static extern bool SetDllDirectory(string path);
  [DllImport("pdfium.dll")] static extern void FPDF_InitLibrary();
  [DllImport("pdfium.dll")] static extern void FPDF_DestroyLibrary();
  [DllImport("pdfium.dll")] static extern IntPtr FPDF_LoadMemDocument64(IntPtr data, UIntPtr length, IntPtr password);
  [DllImport("pdfium.dll")] static extern void FPDF_CloseDocument(IntPtr doc);
  [DllImport("pdfium.dll")] static extern int FPDF_GetPageCount(IntPtr doc);
  [DllImport("pdfium.dll")] static extern IntPtr FPDF_LoadPage(IntPtr doc, int index);
  [DllImport("pdfium.dll")] static extern void FPDF_ClosePage(IntPtr page);
  [DllImport("pdfium.dll")] static extern double FPDF_GetPageWidth(IntPtr page);
  [DllImport("pdfium.dll")] static extern double FPDF_GetPageHeight(IntPtr page);
  [DllImport("pdfium.dll")] static extern IntPtr FPDFBitmap_CreateEx(int width, int height, int format, IntPtr buffer, int stride);
  [DllImport("pdfium.dll")] static extern void FPDFBitmap_Destroy(IntPtr bitmap);
  [DllImport("pdfium.dll")] static extern void FPDFBitmap_FillRect(IntPtr bitmap, int x, int y, int width, int height, uint color);
  [DllImport("pdfium.dll")] static extern void FPDF_RenderPageBitmap(IntPtr bitmap, IntPtr page, int x, int y, int width, int height, int rotation, int flags);

  static Bitmap Render(IntPtr doc, int index) {
    IntPtr page = FPDF_LoadPage(doc, index);
    if (page == IntPtr.Zero) throw new InvalidDataException("Cannot load PDF page");
    try {
      double w = FPDF_GetPageWidth(page) * 200.0 / 72.0;
      double h = FPDF_GetPageHeight(page) * 200.0 / 72.0;
      if (Double.IsNaN(w) || Double.IsNaN(h) || w < 1 || h < 1 ||
          w > 16000 || h > 16000 || w * h > 24000000) {
        throw new InvalidDataException("PDF page exceeds rendering limit");
      }
      Bitmap image = new Bitmap((int)Math.Ceiling(w), (int)Math.Ceiling(h), PixelFormat.Format32bppArgb);
      try {
        BitmapData data = image.LockBits(new Rectangle(0, 0, image.Width, image.Height),
          ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        try {
          IntPtr bitmap = FPDFBitmap_CreateEx(image.Width, image.Height, 4, data.Scan0, data.Stride);
          if (bitmap == IntPtr.Zero) throw new InvalidDataException("Cannot render PDF");
          try {
            FPDFBitmap_FillRect(bitmap, 0, 0, image.Width, image.Height, 0xffffffff);
            FPDF_RenderPageBitmap(bitmap, page, 0, 0, image.Width, image.Height, 0, 0x801);
          } finally { FPDFBitmap_Destroy(bitmap); }
        } finally { image.UnlockBits(data); }
        return image;
      } catch { image.Dispose(); throw; }
    } finally { FPDF_ClosePage(page); }
  }

  public static List<int> SelectPages(string text, int count) {
    if (String.IsNullOrWhiteSpace(text)) {
      List<int> all = new List<int>(); for (int i = 0; i < count; i++) all.Add(i); return all;
    }
    text = text.Replace(" ", "");
    if (text.Length > 128 || !System.Text.RegularExpressions.Regex.IsMatch(text,
        @"^\d{1,3}(-\d{1,3})?(,\d{1,3}(-\d{1,3})?)*$")) throw new InvalidDataException("Invalid page range");
    SortedSet<int> pages = new SortedSet<int>();
    foreach (string part in text.Split(',')) {
      string[] range = part.Split('-'); int first = Int32.Parse(range[0]), last = Int32.Parse(range[range.Length - 1]);
      if (first < 1 || last < first || last > count) throw new InvalidDataException("Page range outside document");
      for (int i = first; i <= last; i++) pages.Add(i - 1);
    }
    return new List<int>(pages);
  }

  public static int Run(string dllDirectory, string path, string printer,
      short copies, string paper, bool landscape, string jobId, bool validateOnly,
      string pages, string duplex, string color, string source, string resolution,
      bool collate, string scaleMode, int marginMm, bool windowsDialog) {
    if (!SetDllDirectory(dllDirectory)) throw new IOException("Cannot load PDF renderer");
    byte[] bytes = File.ReadAllBytes(path);
    if (bytes.Length < 8 || bytes.Length > 25 * 1024 * 1024 ||
        bytes[0] != 37 || bytes[1] != 80 || bytes[2] != 68 || bytes[3] != 70 || bytes[4] != 45) {
      throw new InvalidDataException("Invalid PDF");
    }
    GCHandle pinned = GCHandle.Alloc(bytes, GCHandleType.Pinned);
    IntPtr doc = IntPtr.Zero;
    FPDF_InitLibrary();
    try {
      doc = FPDF_LoadMemDocument64(pinned.AddrOfPinnedObject(), (UIntPtr)bytes.Length, IntPtr.Zero);
      if (doc == IntPtr.Zero) throw new InvalidDataException("Cannot open PDF");
      int count = FPDF_GetPageCount(doc);
      if (count < 1 || count > 100) throw new InvalidDataException("PDF must contain 1 to 100 pages");
      List<int> selected = SelectPages(pages, count);
      if (validateOnly) { using (Bitmap preview = Render(doc, selected[0])) { } return selected.Count; }
      using (PrintDocument print = new PrintDocument()) {
        print.PrinterSettings.PrinterName = printer;
        if (!print.PrinterSettings.IsValid || copies > print.PrinterSettings.MaximumCopies) {
          throw new InvalidDataException("Printer/copy count unavailable");
        }
        print.PrinterSettings.Copies = copies;
        print.PrinterSettings.PrintToFile = false;
        print.PrinterSettings.Collate = collate;
        print.PrintController = new StandardPrintController();
        print.DocumentName = "EasyMsg " + jobId;
        print.DefaultPageSettings.Landscape = landscape;
        int margin = (int)Math.Round(marginMm * 100.0 / 25.4);
        print.DefaultPageSettings.Margins = new Margins(margin, margin, margin, margin);
        PaperSize chosen = null;
        foreach (PaperSize size in print.PrinterSettings.PaperSizes) {
          if ((paper == "a4" && size.Kind == PaperKind.A4) ||
              (paper == "letter" && size.Kind == PaperKind.Letter) ||
              (paper == "photo" && Math.Abs(size.Width - 400) < 10 && Math.Abs(size.Height - 600) < 10) ||
              paper == "p:" + size.RawKind + ":" + size.Width + ":" + size.Height) {
            chosen = size; break;
          }
        }
        if (paper != "default" && chosen == null) throw new InvalidDataException("Requested paper is not supported");
        if (chosen != null) print.DefaultPageSettings.PaperSize = chosen;
        if (color == "color" && !print.PrinterSettings.SupportsColor) throw new InvalidDataException("Color unavailable");
        if (color != "default") print.DefaultPageSettings.Color = color == "color";
        if (duplex != "default") {
          if (duplex != "simplex" && !print.PrinterSettings.CanDuplex) throw new InvalidDataException("Duplex unavailable");
          print.PrinterSettings.Duplex = duplex == "vertical" ? Duplex.Vertical : duplex == "horizontal" ? Duplex.Horizontal : Duplex.Simplex;
        }
        if (source != "default") {
          PaperSource selectedSource = null;
          foreach (PaperSource tray in print.PrinterSettings.PaperSources) {
            if (source == "s:" + tray.RawKind) { selectedSource = tray; break; }
          }
          if (selectedSource == null) throw new InvalidDataException("Paper source unavailable");
          print.DefaultPageSettings.PaperSource = selectedSource;
        }
        if (resolution != "default") {
          PrinterResolution selectedResolution = null;
          foreach (PrinterResolution quality in print.PrinterSettings.PrinterResolutions) {
            if (resolution == "r:" + (int)quality.Kind + ":" + quality.X + ":" + quality.Y) { selectedResolution = quality; break; }
          }
          if (selectedResolution == null) throw new InvalidDataException("Resolution unavailable");
          print.DefaultPageSettings.PrinterResolution = selectedResolution;
        }
        if (windowsDialog) {
          using (PrintDialog dialog = new PrintDialog()) {
            dialog.Document = print; dialog.UseEXDialog = true;
            dialog.AllowPrintToFile = false; dialog.AllowSomePages = true;
            print.PrinterSettings.MinimumPage = 1; print.PrinterSettings.MaximumPage = count;
            print.PrinterSettings.FromPage = 1; print.PrinterSettings.ToPage = count;
            if (dialog.ShowDialog() != DialogResult.OK) return -1;
            if (print.PrinterSettings.PrinterName != printer || print.PrinterSettings.PrintToFile ||
                print.PrinterSettings.Copies < 1 || print.PrinterSettings.Copies > 99 ||
                print.PrinterSettings.Copies > print.PrinterSettings.MaximumCopies) {
              throw new InvalidDataException("Use the selected physical printer without printing to a file");
            }
            selected = print.PrinterSettings.PrintRange == PrintRange.SomePages
              ? SelectPages(print.PrinterSettings.FromPage + "-" + print.PrinterSettings.ToPage, count)
              : SelectPages("", count);
          }
        }
        int index = 0;
        print.PrintPage += delegate(object sender, PrintPageEventArgs e) {
          using (Bitmap image = Render(doc, selected[index++])) {
            RectangleF area = RectangleF.Intersect(e.MarginBounds, e.PageSettings.PrintableArea);
            if (area.Width <= 0 || area.Height <= 0) throw new InvalidDataException("Margins leave no printable area");
            float x = area.Width / image.Width, y = area.Height / image.Height;
            float factor = scaleMode == "actual" ? 0.5f : scaleMode == "fill" ? Math.Max(x, y) : Math.Min(x, y);
            float width = image.Width * factor, height = image.Height * factor;
            System.Drawing.Drawing2D.GraphicsState saved = e.Graphics.Save();
            try {
              e.Graphics.TranslateTransform(-e.PageSettings.HardMarginX, -e.PageSettings.HardMarginY);
              e.Graphics.SetClip(area);
              e.Graphics.DrawImage(image, area.X + (area.Width - width) / 2,
                area.Y + (area.Height - height) / 2, width, height);
            } finally { e.Graphics.Restore(saved); }
          }
          e.HasMorePages = index < selected.Count;
        };
        print.Print();
      }
      return count;
    } finally {
      if (doc != IntPtr.Zero) FPDF_CloseDocument(doc);
      FPDF_DestroyLibrary();
      pinned.Free();
    }
  }
}
'@
  $pages = [EasyMsgPrint]::Run($request.dllDirectory, $pdfPath, $request.printer,
    [int16]$request.copies, $request.paper, $request.landscape, $request.jobId,
    ($request.action -eq 'validate'), $request.pages, $request.duplex, $request.color,
    $request.source, $request.resolution, $request.collate, $request.scale,
    [int]$request.marginMm, $request.windowsDialog)
  @{status = $(if ($pages -lt 0) { 'cancelled' } else { 'submitted' }); pages = $pages} | ConvertTo-Json -Compress
} catch {
  @{error = $_.Exception.GetBaseException().Message} | ConvertTo-Json -Compress
  exit 1
}
