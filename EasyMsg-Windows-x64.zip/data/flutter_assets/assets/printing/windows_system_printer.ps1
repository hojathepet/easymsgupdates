param([Parameter(Mandatory = $true)][string]$Config, [switch]$Elevated)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [Console]::OutputEncoding
$resultPath = Join-Path (Split-Path -LiteralPath $Config) 'result.json'
$result = $null
try {
  $request = Get-Content -LiteralPath $Config -Raw -Encoding UTF8 | ConvertFrom-Json
  if ($request.action -notin @('add', 'remove') -or
      $request.name -isnot [string] -or $request.name.Length -gt 128 -or
      -not $request.name.StartsWith('EasyMsg ') -or $request.name -match '[\x00-\x1f\\/:*?"<>|]' -or
      $request.marker -notmatch '^EasyMsgSystemPrinterV1:[a-f0-9]{64}$' -or
      $request.uri -notmatch '^ipp://127\.0\.0\.1:[0-9]{1,5}/easymsg/[a-f0-9]{64}/[a-f0-9]{32}$') {
    throw 'Invalid EasyMsg system printer configuration'
  }
  $uri = [uri]$request.uri
  if ($uri.Port -lt 1 -or $uri.Port -gt 65535 -or
      $request.marker.Substring(23) -cne $uri.Segments[2].TrimEnd('/')) {
    throw 'Invalid printer endpoint ownership'
  }
  $admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)
  if (-not $admin) {
    if ($Elevated) { throw 'Administrator access was not granted' }
    # Use the exact script and config as separate arguments; no interpolated commands.
    $arguments = @('-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File',
      ('"' + $PSCommandPath + '"'), '-Config', ('"' + $Config + '"'), '-Elevated')
    $child = Start-Process -FilePath 'powershell.exe' -ArgumentList $arguments -Verb RunAs -WindowStyle Hidden -PassThru -Wait
    if (-not (Test-Path -LiteralPath $resultPath)) { throw 'Windows printer setup did not finish' }
    $result = Get-Content -LiteralPath $resultPath -Raw -Encoding UTF8 | ConvertFrom-Json
  } else {
    $existing = @(Get-Printer -Full | Where-Object Name -CEQ $request.name)
    if ($existing.Count -gt 1 -or ($existing.Count -eq 1 -and $existing[0].Comment -cne $request.marker)) {
      throw 'A printer with this name is not owned by EasyMsg. It has not been changed.'
    }
    if ($request.action -eq 'remove') {
      if ($existing.Count -eq 1) { Remove-Printer -Name $request.name }
    } elseif ($existing.Count -eq 0) {
      if (-not (Get-Command Add-Printer).Parameters.ContainsKey('IppURL')) {
        throw 'This Windows version does not support adding an IPP printer. Update Windows first.'
      }
      Add-Printer -Name $request.name -IppURL $request.uri -Comment $request.marker
      Set-Printer -Name $request.name -Comment $request.marker
      if ((Get-Printer -Name $request.name -Full).Comment -cne $request.marker) {
        throw 'Windows did not preserve the EasyMsg printer ownership marker'
      }
    }
    $result = @{ok = $true}
  }
} catch { $result = @{ok = $false; error = $_.Exception.Message} }
$json = $result | ConvertTo-Json -Depth 4 -Compress
if ($Elevated) { [IO.File]::WriteAllText($resultPath, $json, [Text.UTF8Encoding]::new($false)) }
else { [Console]::WriteLine($json) }
if (-not $result.ok) { exit 1 }
